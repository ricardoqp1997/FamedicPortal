from django.apps import AppConfig


class FamedicUsersConfig(AppConfig):
    name = 'famedic_users'
