from django.apps import AppConfig


class FamedicConfig(AppConfig):
    name = 'portal_radicaciones'
    verbose_name = 'Portal de radicaciones'

